// Shared helpers for the phone-OTP recovery functions (file name starts with _ so it is not a route).
const crypto = require('crypto');
const b64u = (b) => Buffer.from(b).toString('base64url');
const sign = (secret, data) => crypto.createHmac('sha256', secret).update(data).digest('base64url');
const eq = (a, b) => { a = Buffer.from(String(a)); b = Buffer.from(String(b)); return a.length === b.length && crypto.timingSafeEqual(a, b); };
const maskPhone = (p) => String(p).slice(0, 3) + '*****' + String(p).slice(-2);

// 10-digit Indian mobile -> +91..., or full +countrycode number. Anything else -> null.
function normalizePhone(s) {
  s = String(s || '').replace(/[\s\-()]/g, '');
  if (/^[6-9]\d{9}$/.test(s)) return '+91' + s;
  if (/^\+[1-9]\d{7,14}$/.test(s)) return s;
  return null;
}
// Per-phone recovery key. Never stored: re-derived from CODE_SECRET + the verified phone number.
function recoveryKey(phone, secret) {
  return crypto.createHmac('sha256', secret).update('recovery-key|' + phone).digest('base64url');
}
async function sendSms(to, body) {
  const sid = process.env.TWILIO_ACCOUNT_SID, tok = process.env.TWILIO_AUTH_TOKEN;
  const p = new URLSearchParams({ To: to, Body: body });
  if (process.env.TWILIO_MESSAGING_SID) p.set('MessagingServiceSid', process.env.TWILIO_MESSAGING_SID);
  else p.set('From', process.env.TWILIO_FROM);
  const r = await fetch('https://api.twilio.com/2010-04-01/Accounts/' + sid + '/Messages.json', {
    method: 'POST',
    headers: { Authorization: 'Basic ' + Buffer.from(sid + ':' + tok).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' },
    body: p.toString()
  });
  return r.ok;
}
function cfg(res) {
  const e = process.env;
  if (!e.CODE_SECRET || !e.TWILIO_ACCOUNT_SID || !e.TWILIO_AUTH_TOKEN || !(e.TWILIO_FROM || e.TWILIO_MESSAGING_SID)) {
    res.status(503).json({ error: 'Phone OTP service configure nahi hai (Vercel environment variables daalo).' });
    return null;
  }
  return { secret: e.CODE_SECRET };
}
// Best-effort rate limit (in-memory: resets when the serverless instance is recycled; not a hard guarantee).
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now(), arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) { hits.set(key, arr); return true; }
  arr.push(now); hits.set(key, arr); return false;
}
module.exports = { crypto, b64u, sign, eq, maskPhone, normalizePhone, recoveryKey, sendSms, cfg, limited };
