// POST /api/phone-verify {otp, code} -> returns the recovery key for the verified phone number.
const { sign, eq, maskPhone, recoveryKey, cfg } = require('./_lib');

module.exports = (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const c = cfg(res); if (!c) return;
  const { otp, code } = req.body || {};
  const [p, h] = String(otp || '').split('.');
  let o; try { o = JSON.parse(Buffer.from(String(p), 'base64url').toString()); } catch (e) { o = null; }
  if (!o || !h || typeof o.ph !== 'string') return res.status(400).json({ error: 'Pehle OTP bhejo.' });
  if (Date.now() > o.x) return res.status(400).json({ error: 'OTP expire ho gaya. Naya bhejo.' });
  if (!eq(sign(c.secret, 'otp.' + p + '.' + String(code || '').trim()), h)) return res.status(400).json({ error: 'OTP galat hai.' });
  res.status(200).json({ rk: recoveryKey(o.ph, c.secret), phone: maskPhone(o.ph) });
};
