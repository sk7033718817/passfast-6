// POST /api/send-code  -> emails a 6-digit code to OWNER_EMAIL (never to an address supplied by the client).
const crypto = require('crypto');

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const { RESEND_API_KEY, MAIL_FROM, CODE_SECRET, OWNER_EMAIL } = process.env;
  if (!RESEND_API_KEY || !MAIL_FROM || !CODE_SECRET || !OWNER_EMAIL) {
    return res.status(503).json({ error: 'Email service configure nahi hai (Vercel environment variables daalo).' });
  }
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  const exp = Date.now() + 10 * 60 * 1000;
  const h = crypto.createHmac('sha256', CODE_SECRET).update(`${OWNER_EMAIL}|${code}|${exp}`).digest('hex');
  let r;
  try {
    r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + RESEND_API_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: MAIL_FROM,
        to: [OWNER_EMAIL],
        subject: 'PassFast verification code',
        text: `Your PassFast verification code is ${code}. It expires in 10 minutes. If you did not request it, ignore this email.`
      })
    });
  } catch (e) {
    return res.status(502).json({ error: 'Email bhej nahi paaye.' });
  }
  if (!r.ok) return res.status(502).json({ error: 'Email bhej nahi paaye.' });
  const [u, d] = OWNER_EMAIL.split('@');
  res.status(200).json({
    token: Buffer.from(JSON.stringify({ x: exp, h })).toString('base64url'),
    to: u[0] + '***@' + d
  });
};
