// POST /api/phone-send {phone} -> SMS a 6-digit OTP to that number. The code is never returned to the browser.
const { crypto, b64u, sign, maskPhone, normalizePhone, sendSms, cfg, limited } = require('./_lib');

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const c = cfg(res); if (!c) return;
  const phone = normalizePhone((req.body || {}).phone);
  if (!phone) return res.status(400).json({ error: 'Sahi mobile number daalo.' });
  const ip = String((req.headers && req.headers['x-forwarded-for']) || '').split(',')[0].trim() || 'ip';
  if (limited('p:' + phone, 5, 60 * 60 * 1000) || limited('i:' + ip, 20, 60 * 60 * 1000)) {
    return res.status(429).json({ error: 'Bahut zyada OTP maange. Thodi der baad try karo.' });
  }
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  const p = b64u(JSON.stringify({ ph: phone, x: Date.now() + 10 * 60 * 1000 }));
  const h = sign(c.secret, 'otp.' + p + '.' + code);
  let ok = false;
  try { ok = await sendSms(phone, 'PassFast code: ' + code + '. 10 min me expire hoga. Kisi ko mat batao.'); } catch (e) {}
  if (!ok) return res.status(502).json({ error: 'SMS bhej nahi paaye.' });
  res.status(200).json({ otp: p + '.' + h, to: maskPhone(phone) });
};
