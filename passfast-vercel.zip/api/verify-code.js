// POST /api/verify-code {token, code} -> {ok:true} if the code matches the signed, unexpired token.
const crypto = require('crypto');

module.exports = (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const { CODE_SECRET, OWNER_EMAIL } = process.env;
  if (!CODE_SECRET || !OWNER_EMAIL) return res.status(503).json({ error: 'Email service configure nahi hai.' });
  const { token, code } = req.body || {};
  let t;
  try { t = JSON.parse(Buffer.from(String(token), 'base64url').toString()); } catch (e) { t = null; }
  if (!t || typeof t.h !== 'string' || typeof t.x !== 'number') return res.status(400).json({ error: 'Pehle code bhejo.' });
  if (Date.now() > t.x) return res.status(400).json({ error: 'Code expire ho gaya. Naya bhejo.' });
  const h = crypto.createHmac('sha256', CODE_SECRET).update(`${OWNER_EMAIL}|${String(code || '').trim()}|${t.x}`).digest('hex');
  const ok = h.length === t.h.length && crypto.timingSafeEqual(Buffer.from(h), Buffer.from(t.h));
  return ok ? res.status(200).json({ ok: true }) : res.status(400).json({ error: 'Code galat hai.' });
};
